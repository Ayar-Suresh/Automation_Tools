import json
import os
import base64
import asyncio
import time
import requests
from telethon import TelegramClient, events, errors

# ================= 1. CONFIGURATION =================
API_ID = 26533694
API_HASH = "36cbb9b7134615f4dd121aac7ba98ae0"
BOT_TOKEN = "8482679681:AAG98ABhFJlCHfyax1gft4ribuCU7nJOn84" 
ADMIN_ID = 8466952185 

# List ALL your source channels here to use as fallbacks
SOURCE_CHANNELS = [
    -1003175788400,  # Channel A
    -1003498912074   # Channel B
]

# Raw GitHub URLs (Mirrors)
INDEX_URLS = [
    "https://raw.githubusercontent.com/OtaKuNexa/anime-index/main/anime_index.json",
    "https://raw.githubusercontent.com/CyberDrift00/anime-index/main/anime_index.json"
]

# Cache Settings
CACHE_DURATION = 3600 # 1 Hour
last_fetch_time = 0   
ANIME_DATA = {}       
AUTO_DELETE_SECONDS = 3600

# ================= 2. INITIALIZATION =================
print("⚙️ Initializing Telegram Client...")
client = TelegramClient("secure_delivery_session", API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# ================= 3. DATA LOADING (SMART CACHE) =================
def fetch_index_from_cloud():
    global last_fetch_time
    print("☁️ Checking Cloud Mirrors...")
    
    for url in INDEX_URLS:
        try:
            print(f"   Trying: {url}...")
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                count = len(data)
                print(f"✅ Success! Loaded {count} animes.")
                last_fetch_time = time.time()
                return data
            else:
                print(f"❌ Failed (Status {response.status_code})")
        except Exception as e:
            print(f"❌ Connection Error: {e}")
    
    print("⚠️ All mirrors failed. Keeping old data.")
    return None

def get_data_with_cache():
    """Returns index. Auto-updates if older than 1 hour."""
    global ANIME_DATA
    
    current_time = time.time()
    age = current_time - last_fetch_time
    
    if not ANIME_DATA or age > CACHE_DURATION:
        print(f"🔄 Data is {int(age)}s old. Refreshing...")
        new_data = fetch_index_from_cloud()
        if new_data:
            ANIME_DATA = new_data
    
    return ANIME_DATA

# ================= 4. UTILS: HUNTER SEARCH (ROBUST) =================
def find_batch_in_season(season_data, batch_key):
    """
    Recursively searches for a batch_key.
    FIX: Now case-insensitive and robust against structure variations.
    """
    target_key = batch_key.lower().strip()

    # 1. Recursive Search
    def search_recursive(data):
        if isinstance(data, dict):
            # Check current level keys
            for k, v in data.items():
                if k.lower().strip() == target_key:
                    return v
            
            # Drill down
            for k, v in data.items():
                if k in ["mal_ids", "missing_episodes", "total_episodes"]: 
                    continue
                if isinstance(v, dict):
                    res = search_recursive(v)
                    if res: return res
        return None

    # 2. Hunt Specials (Fallback logic)
    def hunt_specials(data):
        results = []
        if isinstance(data, dict):
            if "specials" in data and isinstance(data["specials"], dict):
                for val in data["specials"].values():
                    results.append(val)
            for k, v in data.items():
                if isinstance(v, dict) and k not in ["mal_ids", "specials"]:
                    results.extend(hunt_specials(v))
        return results

    # Execution
    result = search_recursive(season_data)
    if result:
        return result if isinstance(result, list) else [result]

    # Handle "Specials" request if exact match failed
    if target_key.startswith("special"):
        all_specials = hunt_specials(season_data)
        all_specials.sort(key=lambda x: x.get('name', ''))
        
        if not all_specials: return None

        try:
            # Parse "Special_1" -> index 0
            clean_num = target_key.replace("special", "").replace("_", "").strip()
            idx = int(clean_num) - 1
            if 0 <= idx < len(all_specials):
                return [all_specials[idx]]
        except: pass
        return all_specials

    return None

# ================= 5. BACKGROUND TASKS =================
async def schedule_delete(client_ref, chat_id, message_ids):
    await asyncio.sleep(AUTO_DELETE_SECONDS)
    try:
        await client_ref.delete_messages(chat_id, message_ids)
    except Exception as e:
        print(f"Failed to auto-delete for {chat_id}: {e}")

# ================= 6. BOT HANDLERS =================

# Refresh Command
@client.on(events.NewMessage(pattern='/refresh'))
async def refresh_data(event):
    if event.sender_id != ADMIN_ID: return
    
    global ANIME_DATA
    msg = await event.reply("🔄 **Forcing Update...**")
    
    new_data = fetch_index_from_cloud()
    
    if new_data:
        ANIME_DATA = new_data
        await msg.edit(f"✅ **Updated!**\nLoaded {len(ANIME_DATA)} animes.\nCache reset.")
    else:
        await msg.edit("❌ **Update Failed.** All URLs are down.")

# Main File Handler
@client.on(events.NewMessage(pattern=r"/start (.+)"))
async def batch_handler(event):
    payload = event.pattern_match.group(1).strip()
    
    try:
        # Decode Payload
        decoded_bytes = base64.urlsafe_b64decode(payload + '===')
        decoded_str = decoded_bytes.decode('utf-8')
        parts = decoded_str.split('|')
        
        if len(parts) != 3:
            await event.reply("❌ **Invalid Token.**")
            return
            
        anime_title, season_key, batch_key = parts
        
        # Get Data
        current_data = get_data_with_cache()
        
        # 1. FIND ANIME
        if anime_title not in current_data:
            await event.reply(f"⚠️ **Anime Not Found:**\n{anime_title}\n\nTry /refresh if you just added it.")
            return

        # 2. FIND SEASON (Case-insensitive match for Mirrors)
        season_data = None
        seasons_node = current_data[anime_title].get("seasons", {})
        
        # Direct lookup first
        if season_key in seasons_node:
            season_data = seasons_node[season_key]
        else:
            # Fallback: Fuzzy search (e.g. "S1 Mirror" matching "S1 Mirror ")
            for k, v in seasons_node.items():
                if k.strip().lower() == season_key.strip().lower():
                    season_data = v
                    break
        
        if not season_data:
            await event.reply(f"⚠️ **Season Not Found:**\n{season_key}\n\nTry /refresh.")
            return

        # 3. FIND FILES
        batch_files = find_batch_in_season(season_data, batch_key)
        
        if not batch_files:
            await event.reply(f"⚠️ **Batch Empty/Not Found:**\n{batch_key}")
            return

        # 4. SEND FILES
        display_name = batch_key.replace('_', ' ').title()
        status_msg = await event.reply(f"📂 **{anime_title}**\n💿 {season_key} - {display_name}\n🚀 Sending files...")

        sent_messages = []
        files_not_found = 0

        for item in batch_files:
            if not isinstance(item, dict): continue
            
            msg_id = item.get('file')
            if not msg_id: continue

            # --- ROBUST CHANNEL SELECTION ---
            channels_to_try = []

            # Priority 1: ID from JSON
            json_ch = item.get('channel_id')
            if json_ch:
                try:
                    # Strip any string formatting if present
                    clean_id = int(str(json_ch).strip())
                    channels_to_try.append(clean_id)
                except: pass

            # Priority 2: Fallback List
            for ch in SOURCE_CHANNELS:
                if ch not in channels_to_try:
                    channels_to_try.append(ch)
            
            # --- FORWARDING LOGIC ---
            file_sent = False
            for channel_id in channels_to_try:
                try:
                    msgs = await client.forward_messages(
                        event.chat_id, 
                        messages=msg_id, 
                        from_peer=channel_id, 
                        drop_author=True 
                    )
                    if msgs:
                        sent_messages.append(msgs)
                        file_sent = True
                        # 🔥 SAFETY DELAY ADDED HERE (0.5s) 🔥
                        await asyncio.sleep(0.5) 
                        break 
                except errors.MessageIdInvalidError:
                    continue 
                except Exception as e:
                    # Common error: Bot not in channel
                    print(f"⚠️ Error forwarding from {channel_id}: {e}")
                    continue
            
            if not file_sent:
                files_not_found += 1
                print(f"❌ Msg {msg_id} not found in {channels_to_try}")

        # Cleanup
        if sent_messages:
            ids = [m.id for m in sent_messages]
            ids.append(status_msg.id)
            asyncio.create_task(schedule_delete(client, event.chat_id, ids))
        else:
            await event.reply("❌ **Delivery Failed:**\nBot could not find these messages.\nMake sure I am Admin in the channel.")

    except Exception as e:
        await event.reply(f"❌ **Error:** {str(e)}")
        print(f"Handler Error: {e}")

@client.on(events.NewMessage(pattern=r"^/start$"))
async def block_direct_access(event):
    await event.reply("⛔ **Access Denied.** Use the App.")

# ================= 7. START =================
print("🔒 Secure Delivery Bot is Running...")
client.run_until_disconnected()
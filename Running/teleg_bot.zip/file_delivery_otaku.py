import json
import os
import base64
import asyncio
import time
import requests
from telethon import TelegramClient, events

# ================= 1. CONFIGURATION =================
API_ID = 26533694
API_HASH = "36cbb9b7134615f4dd121aac7ba98ae0"
BOT_TOKEN = "8482679681:AAG98ABhFJlCHfyax1gft4ribuCU7nJOn84" 
ADMIN_ID = 8466952185 

# 🚨 CRITICAL FIX: Initialize Client HERE (Before using @client decorators)
print("⚙️ Initializing Telegram Client...")
client = TelegramClient("secure_delivery_bot", API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# Source Channels
SOURCE_CHANNELS = [
    -1003175788400,
    -1003498912074
]

# Raw GitHub URLs (Mirrors)
INDEX_URLS = [
    "https://raw.githubusercontent.com/OtaKuNexa/anime-index/main/anime_index.json",
    "https://raw.githubusercontent.com/CyberDrift00/anime-index/main/anime_index.json"
]

# Cache Settings
CACHE_DURATION = 3600 # 1 Hour
last_fetch_time = 0   
ANIME_DATA = {}       
AUTO_DELETE_SECONDS = 3600

# ================= 2. DATA LOADING (SMART CACHE) =================
def fetch_index_from_cloud():
    global last_fetch_time
    print("☁️ Checking Cloud Mirrors...")
    
    for url in INDEX_URLS:
        try:
            print(f"   Trying: {url}...")
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                count = len(data)
                print(f"✅ Success! Loaded {count} animes.")
                last_fetch_time = time.time()
                return data
            else:
                print(f"❌ Failed (Status {response.status_code})")
        except Exception as e:
            print(f"❌ Connection Error: {e}")
    
    print("⚠️ All mirrors failed. Keeping old data.")
    return None

def get_data_with_cache():
    """Returns index. Auto-updates if older than 1 hour."""
    global ANIME_DATA
    
    current_time = time.time()
    age = current_time - last_fetch_time
    
    if not ANIME_DATA or age > CACHE_DURATION:
        print(f"🔄 Data is {int(age)}s old. Refreshing...")
        new_data = fetch_index_from_cloud()
        if new_data:
            ANIME_DATA = new_data
    
    return ANIME_DATA

# Initial Load
ANIME_DATA = fetch_index_from_cloud() or {}

# ================= 3. UTILS: HUNTER SEARCH =================
def find_batch_in_season(season_data, batch_key):
    # Recursive Exact Match
    def search_exact(data, target):
        if isinstance(data, dict):
            if target in data: return data[target]
            for k, v in data.items():
                if isinstance(v, dict) and k not in ["mal_ids", "missing_episodes"]:
                    res = search_exact(v, target)
                    if res: return res
        return None

    # Recursive Special Hunt
    def hunt_specials(data):
        results = []
        if isinstance(data, dict):
            if "specials" in data and isinstance(data["specials"], dict):
                for key, val in data["specials"].items():
                    results.append(val)
            for k, v in data.items():
                if isinstance(v, dict) and k not in ["mal_ids", "missing_episodes", "specials"]:
                    results.extend(hunt_specials(v))
        return results

    # Logic
    exact_match = search_exact(season_data, batch_key)
    if exact_match:
        return exact_match if isinstance(exact_match, list) else [exact_match]

    if batch_key.lower().startswith("special"):
        all_specials = hunt_specials(season_data)
        all_specials.sort(key=lambda x: x.get('name', ''))
        
        if not all_specials: return None

        try:
            clean_key = batch_key.lower().replace("special", "").replace("_", "").strip()
            idx = int(clean_key) - 1
            if 0 <= idx < len(all_specials):
                return [all_specials[idx]]
        except: pass
        
        return all_specials

    return None

# ================= 4. BACKGROUND TASKS =================
async def schedule_delete(client_ref, chat_id, message_ids):
    await asyncio.sleep(AUTO_DELETE_SECONDS)
    try:
        await client_ref.delete_messages(chat_id, message_ids)
    except Exception as e:
        print(f"Failed to auto-delete for {chat_id}: {e}")

# ================= 5. BOT HANDLERS =================

# Refresh Command
@client.on(events.NewMessage(pattern='/refresh'))
async def refresh_data(event):
    if event.sender_id != ADMIN_ID: return
    
    global ANIME_DATA
    msg = await event.reply("🔄 **Forcing Update...**")
    
    new_data = fetch_index_from_cloud()
    
    if new_data:
        ANIME_DATA = new_data
        await msg.edit(f"✅ **Updated!**\nLoaded {len(ANIME_DATA)} animes.\nCache reset.")
    else:
        await msg.edit("❌ **Update Failed.** All URLs are down.")

# Main File Handler
@client.on(events.NewMessage(pattern=r"/start (.+)"))
async def batch_handler(event):
    payload = event.pattern_match.group(1).strip()
    
    try:
        decoded_bytes = base64.urlsafe_b64decode(payload + '===')
        decoded_str = decoded_bytes.decode('utf-8')
        parts = decoded_str.split('|')
        
        if len(parts) != 3:
            await event.reply("❌ **Invalid Token.**")
            return
            
        anime_title, season_num, batch_key = parts
        
        # Get Data (Auto Cache Check)
        current_data = get_data_with_cache()
        
        try:
            if anime_title not in current_data: raise KeyError
            season_data = current_data[anime_title]["seasons"][season_num]
            batch_files = find_batch_in_season(season_data, batch_key)
            if not batch_files: raise KeyError     
        except KeyError:
            await event.reply(f"⚠️ **Content Unavailable:**\nCould not find **{anime_title}**.\nIf updated recently, wait 1 hour or ask Admin to refresh.")
            return

        # Send Files
        display_name = batch_key.replace('_', ' ').title()
        status_msg = await event.reply(f"📂 **{anime_title}** - {display_name}\n🚀 Sending files...")

        sent_messages = []
        for item in batch_files:
            if not isinstance(item, dict): continue
            msg_id = item.get('file')
            if not msg_id: continue

            target_channels = [item['channel_id']] if 'channel_id' in item else SOURCE_CHANNELS
            
            file_sent = False
            for channel_id in target_channels:
                try:
                    msgs = await client.forward_messages(
                        event.chat_id, messages=msg_id, from_peer=channel_id, drop_author=True 
                    )
                    if msgs:
                        sent_messages.append(msgs)
                        file_sent = True
                        break 
                except: continue
            
            if not file_sent: print(f"❌ Failed: {msg_id}")

        if sent_messages:
            ids = [m.id for m in sent_messages]
            ids.append(status_msg.id)
            asyncio.create_task(schedule_delete(client, event.chat_id, ids))
        else:
            await event.reply("❌ **Error:** Source files missing.")

    except Exception as e:
        await event.reply("❌ **Link Invalid.**")
        print(f"Error: {e}")

@client.on(events.NewMessage(pattern=r"^/start$"))
async def block_direct_access(event):
    await event.reply("⛔ **Access Denied.** Use the App.")

# ================= 6. START =================
print("🔒 Secure Delivery Bot is Running (Multi-Mirror Mode)...")
client.run_until_disconnected()